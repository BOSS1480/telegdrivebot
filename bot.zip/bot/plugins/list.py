import math
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery, Message
from bot.config import BotCommands
from bot.helpers.gdrive_utils import GoogleDrive
from bot.helpers.utils import CustomFilters
from bot import LOGGER
from bot.plugins.forcesub import check_forcesub
from bot.db.ban_sql import is_banned
from bot.helpers.sql_helper import idsDB

# קבועים
ITEMS_PER_PAGE = 5
RENAME_STATE = {}

# --- פונקציות עזר ועיצוב ---

def get_file_icon(mime_type):
    if mime_type == 'application/vnd.google-apps.folder':
        return '📂'
    elif 'video' in mime_type:
        return '🎬'
    elif 'image' in mime_type:
        return '🖼️'
    elif 'audio' in mime_type:
        return '🎵'
    elif 'application/pdf' in mime_type:
        return '📕'
    elif 'application/zip' in mime_type or 'compressed' in mime_type:
        return '🗄'
    else:
        return '📄'

def get_gdrive_service(user_id):
    """גישה ישירה ל-API של גוגל"""
    gdrive = GoogleDrive(user_id)
    return gdrive._GoogleDrive__service

def get_parent_id_safe(user_id, file_id):
    """שולף את ה-Parent ID בבטחה"""
    try:
        service = get_gdrive_service(user_id)
        file_meta = service.files().get(
            fileId=file_id, 
            fields='parents', 
            supportsAllDrives=True
        ).execute()
        
        if 'parents' in file_meta and file_meta['parents']:
            return file_meta['parents'][0]
    except Exception:
        pass
    return idsDB.search_parent(user_id)

def check_visibility(user_id, file_id):
    """בודק אם הקובץ ציבורי או פרטי"""
    try:
        service = get_gdrive_service(user_id)
        permissions = service.permissions().list(
            fileId=file_id,
            supportsAllDrives=True
        ).execute()
        
        for perm in permissions.get('permissions', []):
            if perm.get('type') == 'anyone':
                return "ציבורי 🌐"
        return "פרטי 🔒"
    except:
        return "לא ידוע ❓"

def change_permissions(user_id, file_id, role="reader", type="anyone"):
    """
    משנה את הרשאות הקובץ/תיקייה.
    role: 'reader', 'commenter', 'writer'
    type: 'anyone' (ציבורי), 'user' (פרטי - מחיקת הרשאת anyone)
    """
    service = get_gdrive_service(user_id)
    
    if type == "anyone":
        # הופך לציבורי
        permission = {
            'type': 'anyone',
            'role': role,
        }
        service.permissions().create(
            fileId=file_id,
            body=permission,
            supportsAllDrives=True
        ).execute()
        return True
    else:
        # הופך לפרטי (מוחק הרשאות ציבוריות)
        try:
            permissions = service.permissions().list(
                fileId=file_id,
                supportsAllDrives=True
            ).execute()
            
            deleted = False
            for perm in permissions.get('permissions', []):
                if perm.get('type') == 'anyone':
                    service.permissions().delete(
                        fileId=file_id,
                        permissionId=perm.get('id'),
                        supportsAllDrives=True
                    ).execute()
                    deleted = True
            return deleted
        except Exception as e:
            LOGGER.error(f"Error changing permission to private: {e}")
            return False

def get_folder_keyboard(user_id, folder_id, page=0):
    gdrive = GoogleDrive(user_id)
    files = gdrive.getFilesByFolderId(folder_id)
    
    # מיון: תיקיות קודם
    files.sort(key=lambda x: x['mimeType'] != 'application/vnd.google-apps.folder')

    total_files = len(files)
    total_pages = math.ceil(total_files / ITEMS_PER_PAGE)
    
    if page >= total_pages: page = total_pages - 1
    if page < 0: page = 0
    
    start_index = page * ITEMS_PER_PAGE
    end_index = start_index + ITEMS_PER_PAGE
    current_files = files[start_index:end_index]

    keyboard = []
    
    # כפתור הגדרות תיקייה בראש הרשימה
    keyboard.append([InlineKeyboardButton(" הגדרות תיקייה ⚙️", callback_data=f"fsettings|{folder_id}")])
    
    if not files:
        keyboard.append([InlineKeyboardButton("📭 התיקייה ריקה", callback_data="empty")])
    else:
        for file in current_files:
            icon = get_file_icon(file.get('mimeType'))
            name = file.get('name')
            f_id = file.get('id')
            
            if file.get('mimeType') == 'application/vnd.google-apps.folder':
                callback_data = f"n|{f_id}|0"
            else:
                callback_data = f"f|{f_id}"
            
            keyboard.append([InlineKeyboardButton(f"{icon} {name}", callback_data=callback_data)])

    # שורת ניווט
    nav_buttons = []
    if page > 0:
        nav_buttons.append(InlineKeyboardButton("➡️ הקודם", callback_data=f"n|{folder_id}|{page-1}"))
    
    if total_pages > 1:
        nav_buttons.append(InlineKeyboardButton(f"📄 {page+1}/{total_pages}", callback_data="noop"))

    if page < total_pages - 1:
        nav_buttons.append(InlineKeyboardButton("הבא ⬅️", callback_data=f"n|{folder_id}|{page+1}"))
    
    if nav_buttons:
        keyboard.append(nav_buttons)

    # כפתור חזרה לראשי
    root_id = idsDB.search_parent(user_id)
    if folder_id != root_id:
        keyboard.append([InlineKeyboardButton("חזרה 🔙", callback_data=f"n|{root_id}|0")])

    return InlineKeyboardMarkup(keyboard)


# --- הפקודה הראשית ---
@Client.on_message(
    filters.private
    & filters.incoming
    & filters.command(BotCommands.ListFiles)
    & CustomFilters.auth_users
)
async def _listFiles(client, message):
    user_id = message.from_user.id

    if await is_banned(user_id):
        await message.reply_text("⛔️ אתה חסום משימוש בבוט.", quote=True)
        return

    if not await check_forcesub(client, message, user_id):
        return

    sent_msg = await message.reply_text("🔎 **מחפש את הקבצים שלך...**", quote=True)

    parent = idsDB.search_parent(user_id)
    if parent is None:
        await sent_msg.edit("❌ לא מוגדרת תיקייה ראשית. נסה להתחבר מחדש (/auth).")
        return

    try:
        markup = get_folder_keyboard(user_id, parent, 0)
        await sent_msg.edit(
            "🗂 **סייר הקבצים שלך בדרייב:**",
            reply_markup=markup
        )
    except Exception as e:
        await sent_msg.edit(f"❌ שגיאה בטעינה: {str(e)}")


# --- ניהול לחיצות ---
@Client.on_callback_query(filters.regex(r"^(n|f|d|dy|r|rc|l|fsettings|perm|pset|noop)"))
async def handle_callback(client, callback_query: CallbackQuery):
    user_id = callback_query.from_user.id
    data = callback_query.data.split("|")
    action = data[0]
    
    if action == "noop":
        await callback_query.answer()
        return

    # --- ניווט (n) ---
    if action == "n":
        folder_id = data[1]
        page = int(data[2])
        try:
            markup = get_folder_keyboard(user_id, folder_id, page)
            await callback_query.edit_message_text(
                "🗂 **סייר הקבצים שלך בדרייב:**",
                reply_markup=markup
            )
        except Exception as e:
            await callback_query.answer(f"שגיאה: {e}", show_alert=True)

    # --- הגדרות תיקייה (fsettings) ---
    elif action == "fsettings":
        folder_id = data[1]
        
        try:
            service = get_gdrive_service(user_id)
            meta = service.files().get(fileId=folder_id, fields='name, parents', supportsAllDrives=True).execute()
            folder_name = meta.get('name', 'תיקייה')
            
            if 'parents' in meta and meta['parents']:
                parent_id = meta['parents'][0]
            else:
                parent_id = folder_id 

        except:
            folder_name = "תיקייה נוכחית"
            parent_id = folder_id

        # בדיקת סטטוס נוכחי
        status = check_visibility(user_id, folder_id)

        buttons = [
            [InlineKeyboardButton("שינוי שם ✏️", callback_data=f"r|{folder_id}"),
             InlineKeyboardButton("מחיקה 🗑️", callback_data=f"d|{folder_id}")],
            
            [InlineKeyboardButton("פרטיות 🔒/🌐", callback_data=f"perm|{folder_id}|folder"),
             InlineKeyboardButton("קישור 🔗", callback_data=f"l|{folder_id}")],
             
            [InlineKeyboardButton("חזרה 🔙", callback_data=f"n|{folder_id}|0")]
        ]
        
        await callback_query.edit_message_text(
            f"⚙️ **הגדרות תיקייה**\n\n"
            f"📂 **שם:** `{folder_name}`\n"
            f"🛠️ **מצב:** {status}\n\n"
            f"בחר פעולה:",
            reply_markup=InlineKeyboardMarkup(buttons)
        )

    # --- תפריט קובץ (f) ---
    elif action == "f":
        file_id = data[1]
        
        try:
            service = get_gdrive_service(user_id)
            try:
                file_meta = service.files().get(
                    fileId=file_id, 
                    fields='name, size, parents',
                    supportsAllDrives=True
                ).execute()
                
                file_name = file_meta.get('name', 'קובץ ללא שם')
                
                if 'parents' in file_meta and file_meta['parents']:
                    parent_id = file_meta['parents'][0]
                else:
                    parent_id = idsDB.search_parent(user_id)
            except Exception:
                file_name = "קובץ נבחר"
                parent_id = idsDB.search_parent(user_id)

            # בדיקת סטטוס
            status = check_visibility(user_id, file_id)

            buttons = [
                [InlineKeyboardButton("שינוי שם✏️", callback_data=f"r|{file_id}"),
                 InlineKeyboardButton("מחיקה 🗑️", callback_data=f"d|{file_id}")],
                 
                [InlineKeyboardButton("פרטיות 🔒/🌐", callback_data=f"perm|{file_id}|file"),
                 InlineKeyboardButton("קישור 🔗", callback_data=f"l|{file_id}")],
                 
                [InlineKeyboardButton("חזרה 🔙", callback_data=f"n|{parent_id}|0")]
            ]
            
            text = (
                f"📄 **פרטי הקובץ**\n\n"
                f"🏷 **שם:** `{file_name}`\n"
                f"🛠️ **מצב:** {status}\n\n"
                f"👇 **מה תרצה לעשות?**"
            )
            
            await callback_query.edit_message_text(
                text,
                reply_markup=InlineKeyboardMarkup(buttons)
            )
        except Exception as e:
             await callback_query.answer(f"שגיאה: {e}", show_alert=True)

    # --- תפריט הרשאות (perm) ---
    elif action == "perm":
        item_id = data[1]
        item_type = data[2] # 'file' or 'folder'
        
        # זיהוי מצב נוכחי להצגה
        current_status = check_visibility(user_id, item_id)
        
        back_action = f"f|{item_id}" if item_type == "file" else f"fsettings|{item_id}"
        
        buttons = [
            [InlineKeyboardButton("הפוך לציבורי (Anyone) 🌐", callback_data=f"pset|{item_id}|{item_type}|public")],
            [InlineKeyboardButton("הפוך לפרטי (Private) 🔒", callback_data=f"pset|{item_id}|{item_type}|private")],
            [InlineKeyboardButton("חזרה 🔙", callback_data=back_action)]
        ]
        
        item_desc = "הקובץ" if item_type == "file" else "התיקייה"
        
        await callback_query.edit_message_text(
            f"🔐 **ניהול הרשאות**\n\n"
            f"מצב נוכחי: **{current_status}**\n\n"
            f"🌐 **ציבורי:** כל מי שיש לו את הקישור יכול לצפות/להוריד.\n"
            f"🔒 **פרטי:** רק משתמשים מורשים יכולים לגשת.",
            reply_markup=InlineKeyboardMarkup(buttons)
        )

    # --- ביצוע שינוי הרשאות (pset) ---
    elif action == "pset":
        item_id = data[1]
        item_type = data[2]
        mode = data[3] # 'public' or 'private'
        
        back_action = f"f|{item_id}" if item_type == "file" else f"fsettings|{item_id}"
        
        await callback_query.answer("🔄 מעדכן הרשאות...", show_alert=False)
        
        try:
            if mode == "public":
                change_permissions(user_id, item_id, role="reader", type="anyone")
                msg = "✅ **עודכן בהצלחה!**\nהפריט כעת **ציבורי** (Anyone with link)."
            else:
                change_permissions(user_id, item_id, type="user") # מסיר הרשאות ציבוריות
                msg = "✅ **עודכן בהצלחה!**\nהפריט כעת **פרטי**."
            
            buttons = [[InlineKeyboardButton("חזרה 🔙", callback_data=back_action)]]
            await callback_query.edit_message_text(msg, reply_markup=InlineKeyboardMarkup(buttons))
            
        except Exception as e:
            await callback_query.edit_message_text(
                f"❌ שגיאה בעדכון הרשאות: {e}",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("חזרה 🔙", callback_data=back_action)]])
            )

    # --- בקשת מחיקה (d) ---
    elif action == "d":
        file_id = data[1]
        
        try:
            service = get_gdrive_service(user_id)
            meta = service.files().get(fileId=file_id, fields='mimeType', supportsAllDrives=True).execute()
            is_folder = meta.get('mimeType') == 'application/vnd.google-apps.folder'
        except:
            is_folder = False

        back_cb = f"fsettings|{file_id}" if is_folder else f"f|{file_id}"
        
        buttons = [
            [InlineKeyboardButton("כן, מחק 🗑️", callback_data=f"dy|{file_id}")],
            [InlineKeyboardButton("ביטול וחזרה 🔙", callback_data=back_cb)]
        ]
        
        type_text = "התיקייה (וכל התוכן שלה)" if is_folder else "הקובץ"
        
        await callback_query.edit_message_text(
            f"⚠️ **אישור מחיקה**\n\n"
            f"האם אתה בטוח שברצונך למחוק את {type_text}?\n"
            f"**פעולה זו היא סופית ולא ניתן לשחזר.**",
            reply_markup=InlineKeyboardMarkup(buttons)
        )

    # --- ביצוע מחיקה (dy) ---
    elif action == "dy":
        file_id = data[1]
        try:
            parent_id = get_parent_id_safe(user_id, file_id)
            
            service = get_gdrive_service(user_id)
            service.files().delete(fileId=file_id, supportsTeamDrives=True).execute()
            
            await callback_query.answer("🗑️ נמחק בהצלחה!", show_alert=True)
            
            markup = get_folder_keyboard(user_id, parent_id, 0)
            await callback_query.edit_message_text(
                "✅ **הפריט נמחק.**\nחזרת לתיקייה הקודמת:", 
                reply_markup=markup
            )
        except Exception as e:
            await callback_query.answer(f"שגיאה במחיקה: {e}", show_alert=True)
            callback_query.data = f"f|{file_id}"
            await handle_callback(client, callback_query)

    # --- שינוי שם (r) ---
    elif action == "r":
        file_id = data[1]
        
        try:
            service = get_gdrive_service(user_id)
            meta = service.files().get(fileId=file_id, fields='mimeType, parents', supportsAllDrives=True).execute()
            is_folder = meta.get('mimeType') == 'application/vnd.google-apps.folder'
            if 'parents' in meta and meta['parents']:
                parent_id = meta['parents'][0]
            else:
                parent_id = idsDB.search_parent(user_id)
        except:
            is_folder = False
            parent_id = idsDB.search_parent(user_id)

        back_cb = f"fsettings|{file_id}" if is_folder else f"f|{file_id}"
        
        RENAME_STATE[user_id] = {
            "file_id": file_id,
            "parent_id": parent_id,
            "msg_id": callback_query.message.id,
            "chat_id": callback_query.message.chat.id,
            "back_cb": back_cb 
        }
        
        buttons = [[InlineKeyboardButton("ביטול וחזרה 🔙", callback_data=f"rc|{file_id}")]]
        await callback_query.edit_message_text(
            "✏️ **שינוי שם**\n\n"
            "💬 שלח לי כעת את השם החדש.\n"
            "⚠️ לקבצים: אל תשכח סיומת (למשל `.mp4`)!",
            reply_markup=InlineKeyboardMarkup(buttons)
        )

    # --- ביטול שינוי שם (rc) ---
    elif action == "rc":
        file_id = data[1]
        back_cb = f"f|{file_id}"
        if user_id in RENAME_STATE:
            back_cb = RENAME_STATE[user_id].get("back_cb", f"f|{file_id}")
            del RENAME_STATE[user_id]
            
        parts = back_cb.split("|")
        callback_query.data = back_cb
        await handle_callback(client, callback_query)

    # --- קישור הורדה (l) ---
    elif action == "l":
        file_id = data[1]
        
        try:
            service = get_gdrive_service(user_id)
            meta = service.files().get(fileId=file_id, fields='mimeType', supportsAllDrives=True).execute()
            is_folder = meta.get('mimeType') == 'application/vnd.google-apps.folder'
        except:
            is_folder = False
            
        view_link = f"https://drive.google.com/file/d/{file_id}/view"
        download_link = f"https://drive.google.com/uc?id={file_id}&export=download"
        folder_link = f"https://drive.google.com/drive/folders/{file_id}"
        
        back_cb = f"fsettings|{file_id}" if is_folder else f"f|{file_id}"
        buttons = [[InlineKeyboardButton("חזרה 🔙", callback_data=back_cb)]]
        
        if is_folder:
             text = (
                f"🔗 **קישור לתיקייה**\n\n"
                f"📂 [פתח ב-Google Drive]({folder_link})\n\n"
                f"🆔 **מזהה:** `{file_id}`"
            )
        else:
            text = (
                f"🔗 **קישורים להורדה וצפייה**\n"
                f"👁‍🗨 [צפייה]({view_link})\n"
                f"⬇️ [הורדה ישירה]({download_link})\n\n"
                f"🆔 **מזהה:** `{file_id}`"
            )
        
        await callback_query.edit_message_text(
            text,
            reply_markup=InlineKeyboardMarkup(buttons),
            disable_web_page_preview=True
        )

# --- טיפול בטקסט לשינוי שם ---
@Client.on_message(filters.private & filters.text & CustomFilters.auth_users)
async def handle_rename_text(client, message: Message):
    user_id = message.from_user.id
    
    if user_id not in RENAME_STATE:
        return

    state = RENAME_STATE[user_id]
    new_name = message.text.strip()
    
    try:
        await message.delete()
    except:
        pass

    try:
        await client.edit_message_text(
            chat_id=state['chat_id'],
            message_id=state['msg_id'],
            text="🔄 **מעדכן את השם... אנא המתן**"
        )
        
        service = get_gdrive_service(user_id)
        file_metadata = {'name': new_name}
        
        service.files().update(
            fileId=state['file_id'], 
            body=file_metadata,
            supportsAllDrives=True
        ).execute()
        
        del RENAME_STATE[user_id]
        
        buttons = [[InlineKeyboardButton("🔙 חזרה", callback_data=f"n|{state['parent_id']}|0")]]
        
        await client.edit_message_text(
            chat_id=state['chat_id'],
            message_id=state['msg_id'],
            text=f"✅ **השם שונה בהצלחה!**\n\n🏷 השם החדש: `{new_name}`",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
    except Exception as e:
        await client.edit_message_text(
            chat_id=state['chat_id'],
            message_id=state['msg_id'],
            text=f"❌ שגיאה בעדכון השם: {e}"
        )



