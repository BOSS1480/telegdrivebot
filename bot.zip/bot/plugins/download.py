import os
import time
from pyrogram import Client, filters
from bot.helpers.sql_helper import gDriveDB
from bot.helpers.utils import CustomFilters, humanbytes
from bot.helpers.downloader import download_file, utube_dl
from bot.helpers.gdrive_utils import GoogleDrive
from bot.helpers.progress import progress_for_pyrogram, CANCEL_TASKS
from bot import DOWNLOAD_DIRECTORY, LOGGER
from bot.config import Messages, BotCommands
from pyrogram.errors import RPCError
from bot.plugins.forcesub import check_forcesub
from bot.db.ban_sql import is_banned

@Client.on_message(
    filters.private
    & filters.incoming
    & filters.text
    & (filters.command(BotCommands.Download) | filters.regex("^(ht|f)tp*"))
    & CustomFilters.auth_users
)
async def _download(client, message):
    user_id = message.from_user.id
    chat_id = message.chat.id

    if await is_banned(user_id):
        await message.reply_text("You are banned.", quote=True)
        return

    if not await check_forcesub(client, message, user_id):
        return

    # איפוס משימות ביטול
    CANCEL_TASKS[chat_id] = ""

    if not message.media:
        sent_message = await message.reply_text(Messages.CHECKING_LINK, quote=True)
        if message.command:
            link = message.command[1]
        else:
            link = message.text
        
        start_time = time.time()

        if "drive.google.com" in link:
            await sent_message.edit(Messages.CLONING.format(link))
            LOGGER.info(f"Copy:{user_id}: {link}")
            msg = GoogleDrive(user_id).clone(link)
            await sent_message.edit(msg)
        else:
            if "|" in link:
                link, filename = link.split("|")
                link = link.strip()
                filename = filename.strip()
                dl_path = os.path.join(DOWNLOAD_DIRECTORY, filename)
            else:
                link = link.strip()
                dl_path = DOWNLOAD_DIRECTORY

            LOGGER.info(f"Download:{user_id}: {link}")
            
            try:
                if "youtube.com" in link or "youtu.be" in link:
                     result, file_path = await utube_dl(link, sent_message, start_time)
                else:
                     result, file_path = await download_file(link, dl_path, sent_message, start_time)

                # בדיקה אם חזר סטטוס ביטול מהפונקציות
                if file_path == "CANCELLED":
                    await sent_message.edit("❌ **ההורדה בוטלה!**")
                    return
                
                # בדיקה נוספת אם המשתמש ביטל בדיוק ברגע הסיום
                if CANCEL_TASKS.get(chat_id) == "CANCELLED":
                    await sent_message.edit("❌ **ההורדה בוטלה!**")
                    if file_path and os.path.exists(file_path):
                        os.remove(file_path)
                    return

                if result:
                    await sent_message.edit(
                        Messages.DOWNLOADED_SUCCESSFULLY.format(
                            os.path.basename(file_path),
                            humanbytes(os.path.getsize(file_path)),
                        )
                    )
                    
                    await sent_message.edit(f"☁️ **מעלה לדרייב...**\n`{os.path.basename(file_path)}`")
                    
                    try:
                        msg = GoogleDrive(user_id).upload_file(file_path)
                        await sent_message.edit(msg)
                    except Exception as e:
                        await sent_message.edit(f"שגיאה בהעלאה: {e}")

                    if os.path.exists(file_path):
                        os.remove(file_path)
                else:
                    await sent_message.edit(Messages.DOWNLOAD_ERROR.format(file_path))
            
            except Exception as e:
                # תפיסת שגיאות כללית וביטולים
                if "CANCELLED" in str(e) or CANCEL_TASKS.get(chat_id) == "CANCELLED":
                    await sent_message.edit("❌ **ההורדה בוטלה!**")
                else:
                    LOGGER.error(e)
                    await sent_message.edit(Messages.WENT_WRONG)


@Client.on_message(
    filters.private
    & filters.incoming
    & (filters.document | filters.audio | filters.video | filters.photo)
    & CustomFilters.auth_users
)
async def _telegram_file(client, message):
    user_id = message.from_user.id
    chat_id = message.chat.id

    if await is_banned(user_id):
        await message.reply_text("You are banned.", quote=True)
        return

    if not await check_forcesub(client, message, user_id):
        return

    CANCEL_TASKS[chat_id] = ""

    sent_message = await message.reply_text("🕵️ **מכין הורדה...**", quote=True)
    
    if message.document:
        file = message.document
    elif message.video:
        file = message.video
    elif message.audio:
        file = message.audio
    elif message.photo:
        file = message.photo
        setattr(file, "mime_type", "image/png")
        setattr(file, "file_name", f"IMG-{user_id}-{message.id}.png")
    
    file_name = getattr(file, "file_name", f"file_{message.id}")
    file_size = getattr(file, "file_size", 0)
    mime_type = getattr(file, "mime_type", "unknown/unknown")

    # משתמשים במשתנה החדש שנוצר במיוחד להתחלה
    await sent_message.edit(
        Messages.DOWNLOAD_TG_FILE_START.format(file_name, humanbytes(file_size), mime_type)
    )
    
    LOGGER.info(f"Download:{user_id}: {file_name}")
    start_time = time.time()
    
    try:
        file_path = await message.download(
            file_name=DOWNLOAD_DIRECTORY,
            progress=progress_for_pyrogram,
            progress_args=(Messages.DOWNLOADING_TG, sent_message, start_time, CANCEL_TASKS)
        )
        
        # וידוא סופי שהקובץ קיים ולא בוטל
        if CANCEL_TASKS.get(chat_id) == "CANCELLED" or not file_path:
             await sent_message.edit("❌ **ההורדה בוטלה!**")
             if file_path and os.path.exists(file_path):
                 os.remove(file_path)
             return

        await sent_message.edit(
            Messages.DOWNLOADED_SUCCESSFULLY.format(
                os.path.basename(file_path), humanbytes(os.path.getsize(file_path))
            )
        )
        
        await sent_message.edit(f"☁️ **מעלה לדרייב...**\n`{os.path.basename(file_path)}`")
        msg = GoogleDrive(user_id).upload_file(file_path, mime_type)
        await sent_message.edit(msg)
        
    except RPCError as e:
        await sent_message.edit(f"שגיאה: {e}")
    except Exception as e:
        # זה התיקון הקריטי לבאג שראית בלוג
        if "CANCELLED" in str(e) or CANCEL_TASKS.get(chat_id) == "CANCELLED":
            await sent_message.edit("❌ **ההורדה בוטלה!**")
        else:
            await sent_message.edit(Messages.WENT_WRONG)
            LOGGER.error(e)
            
    if file_path and os.path.exists(file_path):
        os.remove(file_path)

@Client.on_message(
    filters.incoming
    & filters.private
    & filters.command(BotCommands.YtDl)
    & CustomFilters.auth_users
)
async def _ytdl(client, message):
    if len(message.command) > 1:
        await _download(client, message)
    else:
        await message.reply_text(Messages.PROVIDE_YTDL_LINK, quote=True)

@Client.on_callback_query(filters.regex("^cancel_process$"))
async def cancel_process_callback(client, callback_query):
    chat_id = callback_query.message.chat.id
    # סימון גלובלי שהמשתמש הזה רוצה לבטל
    CANCEL_TASKS[chat_id] = "CANCELLED"
    
    # הודעת ביניים עד שהלופ תופס את הביטול
    await callback_query.answer("מבטל...", show_alert=False)
    try:
        await callback_query.message.edit("🛑 **מנסה לבטל...**")
    except:
        pass



