import os
import asyncio
import yt_dlp
import wget
from pySmartDL import SmartDL
from urllib.error import HTTPError
from bot import DOWNLOAD_DIRECTORY, LOGGER
from bot.helpers.progress import progress_for_pyrogram, CANCEL_TASKS

async def download_file(url, dl_path, message, start_time):
    try:
        dl = SmartDL(url, dl_path, progress_bar=False)
        LOGGER.info(f"Downloading: {url} in {dl_path}")
        dl.start(blocking=False)
        
        while not dl.isFinished():
            if CANCEL_TASKS.get(message.chat.id) == "CANCELLED":
                dl.stop()
                return False, "CANCELLED"

            if dl.get_dl_size() > 0:
                try:
                    await progress_for_pyrogram(
                        dl.get_dl_size(),
                        dl.get_final_dl_size(),
                        "📥 **מוריד קובץ מאתר...**",
                        message,
                        start_time,
                        CANCEL_TASKS
                    )
                except Exception as e:
                    if str(e) == "CANCELLED":
                        dl.stop()
                        return False, "CANCELLED"
            
            await asyncio.sleep(1)

        if dl.isSuccessful():
            return True, dl.get_dest()
        else:
            try:
                filename = wget.download(url, dl_path)
                return True, os.path.join(f"{DOWNLOAD_DIRECTORY}/{filename}")
            except Exception:
                 return False, dl.get_errors()

    except HTTPError as error:
        return False, error
    except Exception as error:
        return False, error

async def utube_dl(link, message, start_time):
    def progress_hook(d):
        if d['status'] == 'downloading':
            try:
                if CANCEL_TASKS.get(message.chat.id) == "CANCELLED":
                    raise Exception("CANCELLED")
                
                asyncio.run_coroutine_threadsafe(
                    progress_for_pyrogram(
                        d['downloaded_bytes'],
                        d.get('total_bytes') or d.get('total_bytes_estimate') or 0,
                        f"📥 **מוריד וידאו...**",
                        message,
                        start_time,
                        CANCEL_TASKS
                    ),
                    message._client.loop
                )
            except Exception:
                pass

    ytdl_opts = {
        "outtmpl": os.path.join(DOWNLOAD_DIRECTORY, "%(title)s.%(ext)s"),
        "noplaylist": True,
        "logger": LOGGER,
        "progress_hooks": [progress_hook],
        "format": "bestvideo+bestaudio/best",
        "geo_bypass_country": "IN",
    }

    loop = asyncio.get_event_loop()
    try:
        with yt_dlp.YoutubeDL(ytdl_opts) as ytdl:
            info = await loop.run_in_executor(None, lambda: ytdl.extract_info(link, download=True))
            
            if CANCEL_TASKS.get(message.chat.id) == "CANCELLED":
                 return False, "CANCELLED"

            filename = ytdl.prepare_filename(info)
            if os.path.exists(filename):
                return True, filename
            
            return False, "File not found."

    except Exception as e:
        if "CANCELLED" in str(e):
             return False, "CANCELLED"
        return False, str(e)



