import math
import time
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from bot import LOGGER
from bot.config import Messages

# משתנים גלובליים
CANCEL_TASKS = {}
LAST_UPDATE_TIME = {}

async def progress_for_pyrogram(current, total, ud_type, message, start, status_flags=None):
    chat_id = message.chat.id
    
    # בדיקת ביטול
    if status_flags and status_flags.get(chat_id) == "CANCELLED":
        raise Exception("CANCELLED")

    now = time.time()
    diff = now - start
    
    # מניעת הצפה - עדכון רק כל 5 שניות (אלא אם כן הסתיים)
    last_update = LAST_UPDATE_TIME.get(chat_id, 0)
    if (now - last_update) < 5 and current != total:
        return

    LAST_UPDATE_TIME[chat_id] = now

    # חישובים
    percentage = current * 100 / total
    speed = current / diff
    elapsed_time = round(diff) * 1000
    
    if speed > 0:
        time_to_completion = round((total - current) / speed) * 1000
    else:
        time_to_completion = 0
        
    estimated_total_time = TimeFormatter(milliseconds=time_to_completion)

    # יצירת הבר הגרפי
    progress_bar = "{0}{1}".format(
        ''.join(["■" for i in range(math.floor(percentage / 10))]),
        ''.join(["□" for i in range(10 - math.floor(percentage / 10))])
    )

    # יצירת הטקסט המעוצב באמצעות הטמפלייט מ-Config
    try:
        final_text = Messages.PROGRESS_BAR.format(
            ud_type,                        # {0} - כותרת (מוריד מ...)
            progress_bar,                   # {1} - הבר הגרפי
            round(percentage, 2),           # {2} - אחוזים
            humanbytes(current),            # {3} - כמה ירד
            humanbytes(total),              # {4} - סה"כ גודל
            humanbytes(speed),              # {5} - מהירות
            estimated_total_time if estimated_total_time != '' else "0s" # {6} - זמן נותר
        )
    except Exception:
        final_text = f"{ud_type}\n{percentage}%"

    # כפתור ביטול
    cancel_button = InlineKeyboardMarkup(
        [[InlineKeyboardButton("❌ בטל פעולה", callback_data="cancel_process")]]
    )

    try:
        await message.edit(
            text=final_text,
            reply_markup=cancel_button
        )
    except Exception:
        pass

def humanbytes(size):
    if not size:
        return "0B"
    power = 2**10
    n = 0
    Dic_powerN = {0: ' ', 1: 'K', 2: 'M', 3: 'G', 4: 'T'}
    while size > power:
        size /= power
        n += 1
    return str(round(size, 2)) + " " + Dic_powerN[n] + 'B'

def TimeFormatter(milliseconds: int) -> str:
    seconds, milliseconds = divmod(int(milliseconds), 1000)
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    days, hours = divmod(hours, 24)
    tmp = ((str(days) + "d, ") if days else "") + \
        ((str(hours) + "h, ") if hours else "") + \
        ((str(minutes) + "m, ") if minutes else "") + \
        ((str(seconds) + "s, ") if seconds else "")
    return tmp[:-2]



